from typing import List, Sequence, Tuple


def group_by(document, indices: Sequence[int]) -> Tuple[List[str], List[List[str]]]:
    if not indices:
        raise ValueError("At least one column must be selected")
    for index in indices:
        if not 0 <= index < len(document.headers):
            raise ValueError("Column index out of range: {}".format(index))

    headers = [document.headers[index] for index in indices] + ["Count"]
    counts = {}
    for row in document.rows:
        key = tuple(row[index] for index in indices)
        counts[key] = counts.get(key, 0) + 1

    def sort_key(key):
        parts = []
        for value in key:
            try:
                parts.append((0, float(str(value).replace(",", ""))))
            except (TypeError, ValueError):
                parts.append((1, str(value).lower()))
        return tuple(parts)

    rows = [list(key) + [str(count)] for key, count in sorted(counts.items(), key=lambda item: sort_key(item[0]))]
    return headers, rows
