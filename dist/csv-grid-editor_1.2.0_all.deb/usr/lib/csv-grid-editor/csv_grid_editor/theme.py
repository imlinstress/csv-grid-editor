import gi

gi.require_version("Gdk", "3.0")
from gi.repository import Gdk

RAINBOW = [
    "#e06c75",
    "#e5c07b",
    "#98c379",
    "#56b6c2",
    "#61afef",
    "#c678dd",
    "#d19a66",
    "#5fb3b3",
]

DARK_BACKGROUND = "#1e1e1e"
ROW_BACKGROUND = "#252526"
LINE_NUMBER_COLOR = "#858585"
ERROR_BACKGROUND = "#5c2b2b"


def rgba(value):
    color = Gdk.RGBA()
    color.parse(value)
    return color


def column_color(index):
    return rgba(RAINBOW[index % len(RAINBOW)])


def background_color(index, bad=False):
    if bad:
        return rgba(ERROR_BACKGROUND)
    return rgba(ROW_BACKGROUND if index % 2 else DARK_BACKGROUND)
